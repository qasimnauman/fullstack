const books = [
    {
      title: "The Great Gatsby",
      author: "F. Scott Fitzgerald",
      yearPublished: 1925,
      genre: "Classic",
      isAvailable: true
    },
    {
      title: "To Kill a Mockingbird",
      author: "Harper Lee",
      yearPublished: 1960,
      genre: "Fiction",
      isAvailable: false
    },
    {
      title: "1984",
      author: "George Orwell",
      yearPublished: 1949,
      genre: "Dystopian",
      isAvailable: true
    },
    {
      title: "The Hobbit",
      author: "J.R.R. Tolkien",
      yearPublished: 1937,
      genre: "Fantasy"
    },
    {
      title: "Becoming",
      author: "Michelle Obama",
      yearPublished: 2018,
      genre: "Autobiography",
      isAvailable: true
    }
  ];
  