const globalState = {
    userData: {},
    post1: {},
    post2: {},
    post3: {},
    post4: {},
    post5: {},
    friend1: {},
    friend2: {},
};

friends = [];
